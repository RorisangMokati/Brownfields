package za.co.wethinkcode.robotworlds.Client.Robot;

public class SniperRobot extends Robot {

    public SniperRobot() {
        super(5, 3, 2, 2);
    }
}
