package za.co.wethinkcode.robotworlds.Server.World;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
}
