package za.co.wethinkcode.robotworlds.Server.World;

public enum RobotStatus {
    RELOAD,
    REPAIR,
    NORMAL,
    DEAD
}
