package za.co.wethinkcode.robotworlds.Client.Robot;

public class KillerRobot extends Robot {
    public KillerRobot() {
        super(5, 3, 3, 5);
    }
}
