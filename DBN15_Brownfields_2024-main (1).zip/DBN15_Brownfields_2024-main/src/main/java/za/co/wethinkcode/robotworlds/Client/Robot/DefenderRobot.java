package za.co.wethinkcode.robotworlds.Client.Robot;

public class DefenderRobot extends Robot {
    public DefenderRobot() {
        super(2, 3, 5, 5);
    }
}
