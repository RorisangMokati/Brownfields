package WebApi;

public class ClientController {
    public Object dumpWorld() {
        return null;
    }

    public Object fetchWorldFromDatabase(String worldName) {
        return null;
    }

    public Object handleCommand(String command) {
        return null;
    }
}
