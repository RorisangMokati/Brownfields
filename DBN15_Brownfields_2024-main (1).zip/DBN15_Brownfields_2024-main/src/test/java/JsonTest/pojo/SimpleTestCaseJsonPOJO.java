package JsonTest.pojo;

public class SimpleTestCaseJsonPOJO {

    private String command;

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }
}
